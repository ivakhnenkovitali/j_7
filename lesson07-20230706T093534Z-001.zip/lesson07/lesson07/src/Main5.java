public class Main5 {
    public static void main(String[] args) {


        //-128..127

        Integer i1 = new Integer(5);//упаковка
        Integer i2 = 7;//автоупавка
        int p1 = i1.intValue();//распаковка
        int p2 = i2;//автораспаковка

        i1++;

        Integer i3 = 5;
        Integer i4 = 5;
        System.out.println(i3 == i4);
    }
}
