package model;

public class Animal {
    private String nickname;
    private double weight;

    public Animal() {
    }

    public Animal(String nickname, double weight) {
        this.nickname = nickname;
        this.weight = weight;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "nickname='" + nickname + '\'' +
                ", weight=" + weight +
                '}';
    }
}
