import model.Employee;
import model.Person;
import model.Student;

public class Main1 {
    public static void main(String[] args) {
        Person[] people = {
                new Employee("Vasya", 1000),
                new Student("Vitya", 4, 2000),
                new Employee("Masha", 1500),
                new Student("Kolya", 8.5, 150),
                new Student("Sasha", 6.5, 200)
        };

        for (Person person : people) {
            System.out.println(person);
        }

//        double avgIncome = 0.0;
//        for (Person person : people) {
//            avgIncome += person.income();
//        }
//        avgIncome /= people.length;
        System.out.println("Средний доход среди всех: " + Person.avgIncome(people));

        double avgIncomeStudent = 0.0;
        int studentCounter = 0;
        for (Person person : people) {
            //instanceof - определяет принадлежность объекта к классу или подклассу
            if (person instanceof Student) {
                avgIncomeStudent += person.income();
                studentCounter++;
            }
        }
        //проверка studentCounter!=0
        avgIncomeStudent /= studentCounter;
        System.out.println("Средний доход среди студентов: " + avgIncomeStudent);


    }
}
